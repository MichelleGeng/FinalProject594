package edu.upenn.cit594.datamanagement;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import edu.upenn.cit594.data.Parking;
import edu.upenn.cit594.data.Properties;


public class JSONReader implements Reader{
	
	protected String properties;
	protected String population;
	protected String parking;
	
	public JSONReader (String properties, String parking, String population) {
		this.properties = properties;
		this.parking = parking;
		this.population = population;
	}
	
	public List<Parking> getAllParkingInfo() {
	
		JSONParser parser = new JSONParser();
		JSONArray parking_objects = null;
		
		try {
			parking_objects = (JSONArray)parser.parse(new FileReader(parking));
			
		} catch (IOException | ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		List<Parking> parking_list = new ArrayList<Parking>();
		
		Iterator iter = parking_objects.iterator();	
		
		while (iter.hasNext()) {
				
				JSONObject parking = (JSONObject) iter.next();
				String zipcode = (String) parking.get("zip_code").toString();
				String parkingFine = (String) parking.get("fine").toString();
				int parkingFineInt = Integer.parseInt(parkingFine);
				
				String licensePlateState = (String)parking.get("state").toString();
			
				parking_list.add(new Parking(zipcode, parkingFineInt, licensePlateState));
		}
		
		return parking_list;
	}
	
public List<Properties> getAllPropertyInfo(){
		
		Scanner input = null;
		List<Properties> propertiesList = new ArrayList<Properties>();
		
		try {
			
			// read in properties.csv file
			input = new Scanner (new File(properties)); // CAUTION CHANGE THIS TO THE VARIABLE NAME WHEN WE CONNECT IT TO MAIN CLASS, APPLY ELSEWHERE TOO
			
			// read in header files and split into tokens
			String headersOfCSV = input.nextLine();
			String[] headerColumns = headersOfCSV.split(",");
			
			// put header file into ArrayList so we can get the index of the value quickly
			List<String> headerInList = new ArrayList<String>();
			headerInList = Arrays.asList(headerColumns);
		
			// return indices of our desired values from the header file
			int marketValueIndex = headerInList.indexOf("market_value");
			int totalLivableAreaIndex = headerInList.indexOf("total_livable_area");
			int zipcodeIndex = headerInList.indexOf("zip_code");
			
			// counter to be used in while loop below as a sanity check so we know where the rows have different lengths
			int count = 0;
			
			List<Integer> countErrors = new ArrayList<Integer>();
			
			while (input.hasNextLine()) {
				String lineOfProperties = input.nextLine();
				String testArray[]= lineOfProperties.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)"); //regex used to split the string by commas not in quotation marks
				
				// counting all the indices where the size doesn't match, not always false, sometimes missing zipcode or something which doesn't affect our output
				// this is more as a sanity check
				if (testArray.length != headerInList.size()) {
					//System.out.println("Does not match length at index "+ count);
					countErrors.add(count);
				}
				
				// storing the values from the testArray
				String marketValue = testArray[marketValueIndex];
				String totalLivableArea = testArray[totalLivableAreaIndex];
				String zipCode = testArray[zipcodeIndex];
				zipCode = zipCode.substring(0, Math.min(zipCode.length(), 5));
				
				// adding the stored values into the new Properties object for each row
				propertiesList.add(new Properties(marketValue, totalLivableArea, zipCode));
				count++;
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			input.close();
			
		}
		
		return propertiesList;

	} 

	
	public Map<String, Integer> getPopulationByZipcode() {
		
		Map <String, Integer> populationByZipCode = new HashMap<String, Integer>();
		
		//List<Population> populationByZipcode = new ArrayList<Population>();
		
		
		Scanner input = null;
		
		try {
			input = new Scanner (new File(population));
			
			while (input.hasNextLine()) {
				String s = input.nextLine();
				String testArray[] = s.split("\s");
				
				String zipcodeString = testArray[0];
			
				String populationString = testArray[1];
				int populationInteger = Integer.parseInt(populationString);
				
				populationByZipCode.put(zipcodeString, populationInteger);
			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			input.close();
		}	
		
		return populationByZipCode;
		
	}

}
