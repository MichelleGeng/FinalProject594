package edu.upenn.cit594;


import java.util.List;

import edu.upenn.cit594.data.Parking;
import edu.upenn.cit594.datamanagement.JSONReader;
import edu.upenn.cit594.datamanagement.Reader;
import edu.upenn.cit594.datamanagement.csvReader;
import edu.upenn.cit594.processor.Processor;

public class Main {
	
	public static void main (String args[]) {
	
	Reader reader = new JSONReader("properties.csv", "parking.json", "population.txt");
	
	Processor processor = new Processor (reader);
	
	System.out.println(processor.getTotalPopulationByZipcode());
	List<Parking> parkingList = reader.getAllParkingInfo();
	//System.out.println(parkingList);

	processor.getTotalFinesPerCapita();
	
	}

}
