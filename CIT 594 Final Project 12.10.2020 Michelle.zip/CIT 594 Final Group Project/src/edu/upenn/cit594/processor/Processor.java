package edu.upenn.cit594.processor;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;

import edu.upenn.cit594.data.Parking;
import edu.upenn.cit594.data.Population;
import edu.upenn.cit594.datamanagement.Reader;

public class Processor {
	
	protected Reader reader;
	protected Map<String, Integer> zipcodePopulation_map;
	protected List<Parking> parkingList;
	
	public Processor (Reader reader) {
		this.reader = reader;
		zipcodePopulation_map = reader.getPopulationByZipcode(); // gets all my zipcode and associated population from my population.txt
		parkingList = reader.getAllParkingInfo();
	}
	
	// Method 1: Total Population for All ZIP Codes - my hash table for "memo"ization is defined in my constructor
	
	int sum =  0; // global sum variable
	
	public int getTotalPopulationByZipcode() {
		
		
		// from amy office hours: memoization - when doing calculation, see if you already done it
		// store calculation in a map, grab that answer from the map so don't have to redo it
		
		// if totalPopulationSum already has the key
		if (sum > 0) {
			return sum;
			
		}
		else { // if not have the key
			
			sum = calculateSumOfPopulationInZipcode();
			return sum;
		}
	}
	
	private int calculateSumOfPopulationInZipcode () { // this is the "calculate" method to memorize method #1
		for (int population : zipcodePopulation_map.values()) {
			sum += population;
		}
		return sum;
	}
	
	// Method 2: Total Fines Per Capita
	
	// Display total aggregate fines divided by total population for that zip code
	// When writing to the screen, write one ZIP Code per line and list the ZIP Code, then a single space, then the total fines per capita, like this: 19103 0.0284
	// Written in ascending numerical order
	// total fines per capita displayed with four digits, truncated not rounded
	// trailing zeros up to 4 digits 
	// ignore blank zipcodes in the parking file and which the vehicle license plate is not PA
	// should not display any zipcode for which total aggregate fines is zero, population is 0 or unknown (Zipcode is not in the population input file)
	
	TreeMap<String, Double> orderedZipcodeFines = new TreeMap<String, Double>(); // global variable
	
	public TreeMap<String, Double> getTotalFinesPerCapita() {
		 
		if( !orderedZipcodeFines.isEmpty()) {
			 return orderedZipcodeFines;
		 }
		 else {
			 orderedZipcodeFines = calculateTotalFinesPerCapita();
			 return orderedZipcodeFines;
		 }
	}
	
	private TreeMap<String, Double> calculateTotalFinesPerCapita() {
		
	
		// populate getOrderedZipcodes with the zipcode from the population.txt file, fill value as 0.0
		for (String zipcode: zipcodePopulation_map.keySet()) {
			orderedZipcodeFines.put(zipcode, 0.0);
		}
		
		// iterate through the parking folder
		
		for (Parking ticket: parkingList) {
			
			String zipcode = ticket.getZipcode();
			String licensePlateStateString = ticket.getLicensePlateState();
			
			// if zipcode is blank, vehicle license plate is not PA, or zipcode is not in the population file
			if (zipcode.equals("") || !licensePlateStateString.equals("PA") || !orderedZipcodeFines.containsKey(zipcode)) {
				continue; // breaks iteration of the loop and goes onto the next iteration
			}
			
			// get aggregate fines for each zipcode in the original population file
			int parkingFine = ticket.getParkingFine();
			double currentFineSum = orderedZipcodeFines.get(zipcode);
			currentFineSum += parkingFine;
			orderedZipcodeFines.put(zipcode, currentFineSum);
		}
		
		// divide total fines by total population for each zip code
		
		TreeMap <String, Double> totalFinesPerCapita = new TreeMap<String, Double>();
		
		for (String zipcode: orderedZipcodeFines.keySet()) {
			
			int population = zipcodePopulation_map.get(zipcode);
			double totalFine = orderedZipcodeFines.get(zipcode);
			double finePerCapita = totalFine / population;
			totalFinesPerCapita.put(zipcode, finePerCapita);
			
		}
		
		// do a print formatter
		
		for (String zipcode : totalFinesPerCapita.keySet()) {
			
			double numberToBeFormatted = totalFinesPerCapita.get(zipcode);
			if (numberToBeFormatted == 0 ) {
				continue;
			}
			
			DecimalFormat df = new DecimalFormat("#.0000");
			System.out.println(zipcode + " " + df.format(numberToBeFormatted));
		}	
	
		return orderedZipcodeFines;
	}
	
	
}

